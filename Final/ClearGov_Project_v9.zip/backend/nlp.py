import re
from datetime import datetime


def _clean_spaces(value: str) -> str:
    return re.sub(r"\s+", " ", value or "").strip(" .,:;\n\t")


def _normalize_ocr_labels(text: str) -> str:
    """Normalize common OCR mistakes in labels only, not user data."""
    replacements = {
        r"\bSCCCD\b": "SCCCD",
        r"\bCCCD\b": "CCCD",
        r"\bHo\s+T[eé]n\b": "Họ Tên",
        r"\bH[oô]\s+v[aà]\s+t[eê]n\b": "Họ và tên",
        r"\bNam\s+sinh\b": "Năm sinh",
        r"\bDia\s+chi\b": "Địa chỉ",
    }
    result = text
    for pattern, replacement in replacements.items():
        result = re.sub(pattern, replacement, result, flags=re.IGNORECASE)
    return result


def _extract_id(text: str):
    # First look near the CCCD/SCCCD label. This avoids accidentally selecting
    # another 12-digit sequence from a document.
    label_match = re.search(
        r"(?:SCCCD|CCCD|số\s*CCCD|số\s*căn\s*cước)\s*[:\-]?\s*((?:\d[\s-]*){12})",
        text,
        flags=re.IGNORECASE,
    )
    if label_match:
        digits = re.sub(r"\D", "", label_match.group(1))
        if len(digits) == 12:
            return digits

    # Fallback: any standalone 12-digit number.
    match = re.search(r"(?<!\d)\d{12}(?!\d)", text)
    return match.group(0) if match else None


def _extract_year(text: str):
    # Handles both accented and unaccented OCR output:
    # "Năm sinh: 2000", "Nam sinh: 2000", "sinh năm 2000".
    patterns = [
        r"(?:năm\s*sinh|nam\s*sinh|sinh\s*năm|sinh|năm)\s*[:\-]?\s*(?:là\s*)?(19\d{2}|20\d{2})\b",
        r"\b((?:19|20)\d{2})\b",
    ]

    for pattern in patterns:
        match = re.search(pattern, text, flags=re.IGNORECASE)
        if match:
            year = int(match.group(1))
            if 1900 <= year <= datetime.now().year:
                return year
    return None


def _extract_name(text: str):
    # Label-based extraction is much more reliable for uploaded documents.
    patterns = [
        r"(?:Họ\s*Tên|Họ\s*và\s*tên|Ho\s*Ten|Ho\s*va\s*ten)\s*[:\-]?\s*([^\n\r]+)",
        r"(?:tôi|mình|cháu)\s*(?:tên|là)\s+([^\n\r,.]+)",
    ]

    for pattern in patterns:
        match = re.search(pattern, text, flags=re.IGNORECASE)
        if match:
            name = _clean_spaces(match.group(1))
            # Remove accidental trailing fields if OCR put several fields on one line.
            name = re.split(r"\s+(?:Năm\s*sinh|Nam\s*sinh|Địa\s*chỉ|Dia\s*chi|SCCCD|CCCD)\s*[:\-]?", name, maxsplit=1, flags=re.IGNORECASE)[0]
            name = _clean_spaces(name)
            if len(name.split()) >= 2 and re.search(r"[A-Za-zÀ-ỹĐđ]", name):
                return name
    return None


def _extract_address(text: str):
    patterns = [
        r"(?:Địa\s*chỉ|Dia\s*chi|đang\s*ở|ở\s*tại|hiện\s*ở)\s*[:\-]?\s*([^\n\r]+)",
    ]

    for pattern in patterns:
        match = re.search(pattern, text, flags=re.IGNORECASE)
        if match:
            address = _clean_spaces(match.group(1))
            address = re.split(r"\s+(?:SCCCD|CCCD|Họ\s*Tên|Họ\s*và\s*tên|Năm\s*sinh|Nam\s*sinh)\s*[:\-]?", address, maxsplit=1, flags=re.IGNORECASE)[0]
            address = _clean_spaces(address)
            if len(address) >= 5:
                return address
    return None


def extract_fields(text: str):
    """Extract name, birth year, 12-digit CCCD and address from typed/OCR text."""
    text = text or ""
    normalized = _normalize_ocr_labels(text)

    result = {}

    id_number = _extract_id(normalized)
    if id_number:
        result["id_number"] = id_number

    birth_year = _extract_year(normalized)
    if birth_year:
        result["birth_year"] = birth_year

    name = _extract_name(normalized)
    if name:
        result["name"] = name

    address = _extract_address(normalized)
    if address:
        result["address"] = address

    return {
        "fields": result,
        "raw_text": text,
    }
