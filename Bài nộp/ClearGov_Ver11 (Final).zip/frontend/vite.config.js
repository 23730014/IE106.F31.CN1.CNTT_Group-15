/* ================================================================
 * GHI CHÚ CHI TIẾT - frontend/vite.config.js
 * Chú thích được thêm để giải thích vai trò từng phần mã và luồng xử lý.
 * ================================================================ */

import { defineConfig } from 'vite'
import vue from '@vitejs/plugin-vue'

export default defineConfig({
  plugins: [vue()],
  server: {
    port: 5173
  }
})
