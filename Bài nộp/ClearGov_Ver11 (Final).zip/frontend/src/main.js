/* ================================================================
 * GHI CHÚ CHI TIẾT - frontend/src/main.js
 * Chú thích được thêm để giải thích vai trò từng phần mã và luồng xử lý.
 * ================================================================ */

import { createApp } from 'vue'
import App from './App.vue'
import './style.css'

createApp(App).mount('#app')
