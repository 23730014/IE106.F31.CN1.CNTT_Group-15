<!-- ============================================================
GHI CHÚ CHI TIẾT - frontend/src/components/ChatBubble.vue
Các chú thích trong file giải thích cấu trúc giao diện, luồng xử lý
và cách dữ liệu form được ánh xạ từ câu trả lời người dùng.
============================================================ -->

<template>
  <div :class="['message-row', role]">
    <div v-if="role === 'bot'" class="avatar" aria-hidden="true">🤖</div>
    <div class="bubble">{{ text }}</div>
  </div>
</template>

<script setup>
defineProps({
  role: {
    type: String,
    required: true,
    validator: value => ['bot', 'user'].includes(value)
  },
  text: { type: String, required: true }
})
</script>
