<!-- ============================================================
GHI CHÚ CHI TIẾT - frontend/src/components/FieldHint.vue
Các chú thích trong file giải thích cấu trúc giao diện, luồng xử lý
và cách dữ liệu form được ánh xạ từ câu trả lời người dùng.
============================================================ -->

<template>
  <p class="field-hint">
    <span aria-hidden="true">💡</span> {{ text }}
  </p>
</template>

<script setup>
defineProps({
  text: { type: String, required: true }
})
</script>
