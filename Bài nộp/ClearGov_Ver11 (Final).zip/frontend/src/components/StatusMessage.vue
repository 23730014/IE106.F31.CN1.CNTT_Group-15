<!-- ============================================================
GHI CHÚ CHI TIẾT - frontend/src/components/StatusMessage.vue
Các chú thích trong file giải thích cấu trúc giao diện, luồng xử lý
và cách dữ liệu form được ánh xạ từ câu trả lời người dùng.
============================================================ -->

<template>
  <div
    v-if="text"
    :class="variant === 'error' ? 'upload-error' : 'ocr-status'"
    :role="variant === 'error' ? 'alert' : 'status'"
    :aria-live="variant === 'error' ? undefined : 'polite'"
  >
    <span v-if="variant === 'error'" aria-hidden="true">⚠️ </span>{{ text }}
  </div>
</template>

<script setup>
defineProps({
  variant: {
    type: String,
    default: 'info', // 'info' | 'error'
    validator: value => ['info', 'error'].includes(value)
  },
  text: { type: String, default: '' }
})
</script>
