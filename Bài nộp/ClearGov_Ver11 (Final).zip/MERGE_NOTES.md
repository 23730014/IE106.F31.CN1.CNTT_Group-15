<!-- GHI CHÚ: File MERGE_NOTES.md; mô tả chi tiết mục đích và cách sử dụng nội dung. -->

# ClearGov – bản hoàn chỉnh

Bản này được ghép từ:
- `ClearGov_Project_V9.zip`: giữ backend FastAPI/NLP/TTS và cấu trúc dự án.
- `ClearGov_Project fix.rar`: dùng toàn bộ frontend đã FIX, gồm các component mới, field hint, nút quay lại, xử lý lỗi inline, accessibility, responsive và design tokens.

Frontend không dùng `node_modules` đóng gói trong file ZIP; chạy `npm install` trước khi build.

## Chạy

### Backend
```bash
cd backend
python -m venv venv
# Windows: venv\\Scripts\\activate
# macOS/Linux: source venv/bin/activate
pip install -r requirements.txt
uvicorn main:app --reload
```

### Frontend
```bash
cd frontend
npm install
npm run dev
```

Mở `http://localhost:5173`.
